import { Leaf, Instagram, Facebook } from "lucide-react";
import { FaPinterest } from "react-icons/fa";
import { Check } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-green-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <Leaf className="mr-2" />
              Buddha Bowls
            </h3>
            <p className="green-200 mb-4">
              Nutrición completa y equilibrada para un estilo de vida saludable.
            </p>
            <div className="flex space-x-4">
              <button className="green-200 hover:text-white transition-colors">
                <Instagram size={24} />
              </button>
              <button className="green-200 hover:text-white transition-colors">
                <Facebook size={24} />
              </button>
              <button className="green-200 hover:text-white transition-colors">
                <FaPinterest size={24} />
              </button>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Enlaces útiles</h4>
            <ul className="space-y-2 green-200">
              <li>
                <button
                  onClick={() => scrollToSection("que-es")}
                  className="hover:text-white transition-colors"
                >
                  ¿Qué es un Bowl?
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("valor")}
                  className="hover:text-white transition-colors"
                >
                  Beneficios
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("receta")}
                  className="hover:text-white transition-colors"
                >
                  Receta
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Nutrición</h4>
            <ul className="space-y-2 green-200 text-sm">
              <li className="flex items-center">
                <Check className="mr-2 red-400 flex-shrink-0" size={16} />
                Rico en antioxidantes
              </li>
              <li className="flex items-center">
                <Check className="mr-2 red-400 flex-shrink-0" size={16} />
                Alto contenido en fibra
              </li>
              <li className="flex items-center">
                <Check className="mr-2 red-400 flex-shrink-0" size={16} />
                Fuente de omega-3
              </li>
              <li className="flex items-center">
                <Check className="mr-2 red-400 flex-shrink-0" size={16} />
                Proteínas completas
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-green-700 mt-8 pt-8 text-center green-200">
          <p>&copy; 2024 Buddha Bowls. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
