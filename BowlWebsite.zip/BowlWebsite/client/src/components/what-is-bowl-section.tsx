import { Utensils, Dumbbell, Carrot, Droplet, Leaf } from "lucide-react";

export default function WhatIsBowlSection() {
  return (
    <section id="que-es" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            ¿Qué es un Bowl?
          </h2>
          <div className="w-24 h-1 bg-green-600 mx-auto"></div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Buddha bowl con quinoa, verduras y aguacate"
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>
          <div className="space-y-6">
            <p className="text-lg text-gray-700 leading-relaxed">
              Un <strong className="green-700">bowl</strong> (o tazón en español) en el contexto culinario, especialmente un <strong className="green-700">Buddha Bowl</strong>, es una comida completa servida en un solo recipiente.
            </p>
            
            <div className="bg-green-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold green-800 mb-4 flex items-center">
                <Utensils className="mr-2 green-600" />
                Componentes principales:
              </h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <Leaf className="mt-1 mr-3 green-600 flex-shrink-0" size={20} />
                  <span><strong>Base:</strong> Granos o cereales (quinua, arroz, farro)</span>
                </li>
                <li className="flex items-start">
                  <Dumbbell className="mt-1 mr-3 green-600 flex-shrink-0" size={20} />
                  <span><strong>Proteína:</strong> Tofu, garbanzos, pollo, etc.</span>
                </li>
                <li className="flex items-start">
                  <Carrot className="mt-1 mr-3 green-600 flex-shrink-0" size={20} />
                  <span><strong>Verduras:</strong> Frescas o cocidas</span>
                </li>
                <li className="flex items-start">
                  <Droplet className="mt-1 mr-3 green-600 flex-shrink-0" size={20} />
                  <span><strong>Aderezo:</strong> Salsas nutritivas</span>
                </li>
              </ul>
            </div>
            
            <p className="text-lg text-gray-700 leading-relaxed">
              Su nombre <em>"Buddha"</em> proviene de su presentación abundante y equilibrada, inspirada en la idea de una comida que nutre tanto el cuerpo como la mente. Es popular por su versatilidad, adaptabilidad a dietas y su atractivo visual.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
