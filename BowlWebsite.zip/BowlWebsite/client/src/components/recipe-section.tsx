import { Users, Clock, Utensils, List, Leaf, Dumbbell, Carrot, Star, Droplet, Plus, Lightbulb } from "lucide-react";

export default function RecipeSection() {
  const preparationSteps = [
    {
      title: "Cocina la quinua",
      description: "Hierve 1 taza de quinua con 2 tazas de agua por 15 minutos. Reserva.",
      number: 1
    },
    {
      title: "Prepara la proteína", 
      description: "Asa el tofu o garbanzos con aceite de oliva, sal y pimentón a 200°C durante 20 minutos.",
      number: 2
    },
    {
      title: "Saltea las verduras",
      description: "En una sartén, cocina el kale o espinaca con un chorrito de aceite y sal por 3-5 minutos.",
      number: 3
    },
    {
      title: "Mezcla el aderezo",
      description: "Combina tahini, limón, miel, sal y pimienta. Añade agua si necesitas que sea más líquido.",
      number: 4
    },
    {
      title: "Arma el bowl",
      description: "En un plato, coloca la quinua como base, añade el tofu/garbanzos, verduras, aguacate y espolvorea chía, spirulina y nueces.",
      number: 5
    },
    {
      title: "Sirve",
      description: "Vierte el aderezo por encima y disfruta fresco.",
      number: 6
    }
  ];

  return (
    <section id="receta" className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Receta: Bowl de Buddha Saludable
          </h2>
          <div className="w-24 h-1 bg-green-600 mx-auto mb-6"></div>
          <div className="flex justify-center space-x-8 text-sm text-gray-600">
            <div className="flex items-center">
              <Users className="mr-2 green-600" size={16} />
              <span>2 porciones</span>
            </div>
            <div className="flex items-center">
              <Clock className="mr-2 green-600" size={16} />
              <span>25-30 minutos</span>
            </div>
            <div className="flex items-center">
              <Utensils className="mr-2 green-600" size={16} />
              <span>Fácil</span>
            </div>
          </div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Ingredients Section */}
          <div className="bg-green-50 p-8 rounded-xl">
            <h3 className="text-2xl font-bold green-800 mb-6 flex items-center">
              <List className="mr-3" />
              Ingredientes
            </h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="font-semibold green-700 mb-3 flex items-center">
                  <Leaf className="mr-2 green-500" size={18} />
                  Base
                </h4>
                <ul className="space-y-2 ml-6">
                  <li className="text-gray-700">1 taza de quinua cocida (rica en proteínas y fibra)</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold green-700 mb-3 flex items-center">
                  <Dumbbell className="mr-2 green-500" size={18} />
                  Proteína
                </h4>
                <ul className="space-y-2 ml-6">
                  <li className="text-gray-700">200 g de tofu o garbanzos asados</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold green-700 mb-3 flex items-center">
                  <Carrot className="mr-2 green-500" size={18} />
                  Verduras
                </h4>
                <ul className="space-y-2 ml-6">
                  <li className="text-gray-700">1 taza de kale o espinaca salteada</li>
                  <li className="text-gray-700">½ aguacate en rodajas</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold green-700 mb-3 flex items-center">
                  <Star className="mr-2 green-500" size={18} />
                  Superalimentos
                </h4>
                <ul className="space-y-2 ml-6">
                  <li className="text-gray-700">1 cucharada de semillas de chía o linaza</li>
                  <li className="text-gray-700">1 cucharadita de spirulina (opcional)</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold green-700 mb-3 flex items-center">
                  <Droplet className="mr-2 green-500" size={18} />
                  Aderezo
                </h4>
                <ul className="space-y-2 ml-6">
                  <li className="text-gray-700">2 cucharadas de tahini</li>
                  <li className="text-gray-700">Jugo de ½ limón</li>
                  <li className="text-gray-700">1 cucharadita de miel o sirope de arce</li>
                  <li className="text-gray-700">Sal y pimienta al gusto</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold green-700 mb-3 flex items-center">
                  <Plus className="mr-2 green-500" size={18} />
                  Extra
                </h4>
                <ul className="space-y-2 ml-6">
                  <li className="text-gray-700">1 puñado de almendras o nueces picadas</li>
                </ul>
              </div>
            </div>
          </div>
          
          {/* Preparation Steps */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <List className="mr-3 green-600" />
              Preparación
            </h3>
            
            <div className="space-y-6">
              {preparationSteps.map((step, index) => (
                <div key={index} className="flex space-x-4">
                  <div className={`flex-shrink-0 w-10 h-10 ${step.number === 6 ? 'bg-red-600' : 'bg-green-600'} text-white rounded-full flex items-center justify-center font-bold`}>
                    {step.number}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-2">{step.title}</h4>
                    <p className="text-gray-700">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8 p-6 bg-red-50 rounded-lg">
              <h4 className="font-semibold red-800 mb-3 flex items-center">
                <Lightbulb className="mr-2" size={18} />
                Beneficios de esta receta
              </h4>
              <p className="red-700 text-sm">
                <strong>Tiempo:</strong> 25-30 minutos<br />
                <strong>Beneficios:</strong> Rico en antioxidantes, omega-3 y fibra, ideal para una dieta equilibrada.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <img
            src="https://images.unsplash.com/photo-1569718212165-3a8278d5f624?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&h=600"
            alt="Buddha bowl terminado con todos los ingredientes"
            className="rounded-2xl shadow-2xl mx-auto max-w-4xl w-full"
          />
          <p className="text-sm text-gray-500 mt-4">Tu Buddha Bowl está listo para disfrutar</p>
        </div>
      </div>
    </section>
  );
}
