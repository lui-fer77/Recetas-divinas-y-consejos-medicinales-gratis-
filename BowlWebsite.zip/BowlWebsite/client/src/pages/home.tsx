import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import WhatIsBowlSection from "@/components/what-is-bowl-section";
import ValueSection from "@/components/value-section";
import RecipeSection from "@/components/recipe-section";
import ReactionSection from "@/components/reaction-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <WhatIsBowlSection />
      <ValueSection />
      <RecipeSection />
      <ReactionSection />
      <Footer />
    </div>
  );
}
