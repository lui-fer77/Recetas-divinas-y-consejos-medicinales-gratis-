# Buddha Bowls Web Application

## Overview

This is a full-stack web application focused on Buddha Bowls - a healthy eating concept. The application provides comprehensive information about Buddha Bowls, including nutritional benefits, recipes, and preparation guides. It's built as a modern single-page application with a clean, responsive design optimized for both desktop and mobile devices.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom color schemes (sage and earth tones)
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **State Management**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Structure**: RESTful API with `/api` prefix routing
- **Middleware**: Custom logging, JSON parsing, and error handling
- **Development**: Hot module replacement via Vite integration

### Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless database
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Shared schema definitions between client and server
- **Migrations**: Drizzle Kit for database migrations
- **Temporary Storage**: In-memory storage implementation for development

## Key Components

### Frontend Components
1. **Layout Components**
   - Navigation bar with smooth scrolling
   - Hero section with call-to-action buttons
   - Footer with social media links

2. **Content Sections**
   - What is a Bowl explanation
   - Nutritional value presentation
   - Step-by-step recipe guide
   - Benefits and value propositions

3. **UI Elements**
   - Responsive design components
   - Custom icons and imagery
   - Interactive buttons and navigation
   - Toast notifications system

### Backend Infrastructure
1. **Storage Interface**: Abstracted storage layer supporting multiple implementations
2. **Route Registration**: Centralized route management system
3. **Development Server**: Vite integration for seamless development experience
4. **Error Handling**: Comprehensive error middleware with structured responses

### Shared Resources
- **Schema Definitions**: Type-safe database schemas using Drizzle and Zod
- **Type Safety**: End-to-end TypeScript implementation
- **Path Aliases**: Organized import structure with custom path mapping

## Data Flow

1. **Client Requests**: Browser sends requests through Wouter routing
2. **API Calls**: TanStack Query manages server state and caching
3. **Backend Processing**: Express routes handle API requests
4. **Database Operations**: Drizzle ORM performs type-safe database queries
5. **Response Handling**: Structured JSON responses with error handling
6. **State Updates**: React Query automatically updates UI state

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **@tanstack/react-query**: Server state management and caching
- **drizzle-orm**: Type-safe database ORM
- **@radix-ui/***: Accessible UI component primitives
- **tailwindcss**: Utility-first CSS framework
- **wouter**: Minimalist routing library

### Development Tools
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Replit-specific development tools
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript bundler for production

### UI Enhancement
- **lucide-react**: Modern icon library
- **class-variance-authority**: Utility for component variants
- **clsx**: Conditional CSS class utility
- **date-fns**: Date manipulation library

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot reload
- **API Integration**: Express server with Vite middleware
- **Database**: Neon PostgreSQL with environment-based configuration
- **Type Checking**: Continuous TypeScript compilation

### Production Build
- **Frontend**: Vite optimized build with code splitting
- **Backend**: ESBuild bundling for Node.js deployment
- **Static Assets**: Served from `dist/public` directory
- **Database**: Production PostgreSQL via DATABASE_URL environment variable

### Configuration Management
- **Environment Variables**: DATABASE_URL for database connection
- **Path Resolution**: Custom aliases for clean imports
- **Build Optimization**: Separate client and server build processes
- **Deployment**: Single command deployment with `npm start`

The application follows modern web development best practices with a focus on type safety, developer experience, and responsive design. The architecture supports easy scaling and maintenance while providing a smooth user experience for learning about and preparing Buddha Bowls.