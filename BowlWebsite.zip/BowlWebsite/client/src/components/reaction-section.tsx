import { useState } from "react";
import { Heart, ThumbsUp, Star, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ReactionSection() {
  const [likes, setLikes] = useState(247);
  const [hearts, setHearts] = useState(189);
  const [stars, setStars] = useState(156);
  const [hasLiked, setHasLiked] = useState(false);
  const [hasHearted, setHasHearted] = useState(false);
  const [hasStarred, setHasStarred] = useState(false);

  const handleLike = () => {
    if (hasLiked) {
      setLikes(likes - 1);
    } else {
      setLikes(likes + 1);
    }
    setHasLiked(!hasLiked);
  };

  const handleHeart = () => {
    if (hasHearted) {
      setHearts(hearts - 1);
    } else {
      setHearts(hearts + 1);
    }
    setHasHearted(!hasHearted);
  };

  const handleStar = () => {
    if (hasStarred) {
      setStars(stars - 1);
    } else {
      setStars(stars + 1);
    }
    setHasStarred(!hasStarred);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Buddha Bowls - Nutrición Completa',
        text: 'Descubre el equilibrio perfecto entre sabor, nutrición y bienestar',
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Enlace copiado al portapapeles');
    }
  };

  return (
    <section id="reacciones" className="py-16 bg-gradient-to-r from-green-50 to-neutral-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold neutral-800 mb-4">
          ¿Te gustó esta información?
        </h2>
        <div className="w-24 h-1 bg-red-500 mx-auto mb-8"></div>
        <p className="text-xl neutral-600 mb-12 max-w-2xl mx-auto">
          Comparte tu reacción y ayuda a otros a descubrir el mundo de los Buddha Bowls
        </p>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex flex-col items-center">
            <Button
              onClick={handleLike}
              variant={hasLiked ? "default" : "outline"}
              className={`w-16 h-16 rounded-full mb-3 transition-all transform hover:scale-110 ${
                hasLiked 
                  ? "bg-green-600 hover:bg-green-700 text-white" 
                  : "border-2 border-green-600 text-green-600 hover:bg-green-50"
              }`}
            >
              <ThumbsUp size={24} />
            </Button>
            <span className="font-semibold green-700">{likes}</span>
            <span className="text-sm neutral-500">Me gusta</span>
          </div>
          
          <div className="flex flex-col items-center">
            <Button
              onClick={handleHeart}
              variant={hasHearted ? "default" : "outline"}
              className={`w-16 h-16 rounded-full mb-3 transition-all transform hover:scale-110 ${
                hasHearted 
                  ? "bg-red-600 hover:bg-red-700 text-white" 
                  : "border-2 border-red-600 text-red-600 hover:bg-red-50"
              }`}
            >
              <Heart size={24} />
            </Button>
            <span className="font-semibold red-700">{hearts}</span>
            <span className="text-sm neutral-500">Me encanta</span>
          </div>
          
          <div className="flex flex-col items-center">
            <Button
              onClick={handleStar}
              variant={hasStarred ? "default" : "outline"}
              className={`w-16 h-16 rounded-full mb-3 transition-all transform hover:scale-110 ${
                hasStarred 
                  ? "bg-yellow-500 hover:bg-yellow-600 text-white" 
                  : "border-2 border-yellow-500 text-yellow-600 hover:bg-yellow-50"
              }`}
            >
              <Star size={24} />
            </Button>
            <span className="font-semibold text-yellow-600">{stars}</span>
            <span className="text-sm neutral-500">Favorito</span>
          </div>
          
          <div className="flex flex-col items-center">
            <Button
              onClick={handleShare}
              variant="outline"
              className="w-16 h-16 rounded-full mb-3 transition-all transform hover:scale-110 border-2 border-neutral-400 text-neutral-600 hover:bg-neutral-50"
            >
              <Share2 size={24} />
            </Button>
            <span className="font-semibold neutral-600">Compartir</span>
            <span className="text-sm neutral-500">Con amigos</span>
          </div>
        </div>
        
        <div className="mt-12 p-6 bg-white rounded-xl shadow-lg">
          <h3 className="text-xl font-semibold green-800 mb-3">
            ¡Gracias por tu interacción!
          </h3>
          <p className="neutral-600">
            Tu apoyo nos motiva a seguir compartiendo contenido saludable y nutritivo.
            No olvides seguir nuestras redes sociales para más recetas y tips de nutrición.
          </p>
        </div>
      </div>
    </section>
  );
}