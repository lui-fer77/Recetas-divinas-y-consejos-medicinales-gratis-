import { Heart, Leaf, Clock, Camera } from "lucide-react";

export default function ValueSection() {
  const valuePoints = [
    {
      icon: Heart,
      title: "Nutricional",
      description: "Balance perfecto de carbohidratos, proteínas y grasas saludables. Ingredientes como quinua y aguacate apoyan la salud cardiovascular.",
      color: "sage"
    },
    {
      icon: Leaf,
      title: "Salud", 
      description: "Fomenta el consumo de vegetales y superalimentos, alineándose con dietas antiinflamatorias y sostenibles.",
      color: "earth"
    },
    {
      icon: Clock,
      title: "Practicidad",
      description: "Rápido de preparar (25-30 minutos) y permite usar sobras, reduciendo el desperdicio de alimentos.",
      color: "sage"
    },
    {
      icon: Camera,
      title: "Estética",
      description: "Presentación colorida ideal para compartir en redes sociales, aumentando su popularidad en 2025.",
      color: "earth"
    }
  ];

  return (
    <section id="valor" className="py-16 md:py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Valor de un Bowl
          </h2>
          <div className="w-24 h-1 bg-green-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Descubre por qué los Buddha Bowls son la elección perfecta para una alimentación consciente y saludable
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {valuePoints.map((point, index) => {
            const IconComponent = point.icon;
            return (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                <div className="text-center">
                  <div className={`w-16 h-16 ${point.color === 'sage' ? 'bg-green-100' : 'bg-red-100'} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <IconComponent className={`text-2xl ${point.color === 'sage' ? 'green-600' : 'red-600'}`} size={32} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{point.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {point.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-16 bg-gradient-to-r from-green-700 to-green-800 rounded-2xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">Beneficios Comprobados</h3>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold red-200 mb-2">85%</div>
              <p className="green-100">Más antioxidantes que comidas tradicionales</p>
            </div>
            <div>
              <div className="text-3xl font-bold red-200 mb-2">30min</div>
              <p className="green-100">Tiempo promedio de preparación</p>
            </div>
            <div>
              <div className="text-3xl font-bold red-200 mb-2">100%</div>
              <p className="green-100">Personalizable según tu dieta</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
